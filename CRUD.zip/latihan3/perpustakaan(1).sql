-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2019 at 09:05 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `npm` char(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jurusan` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `nohp` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `npm`, `nama`, `jurusan`, `alamat`, `nohp`, `email`) VALUES
(3, '1102171153', 'Nurul Azizah', 'Ilmu Komputer', 'kampung Kalapa Lima', '08976543214', 'nurul@gmail.com'),
(4, '1102171151', 'islahatun Nufusi', 'Teknik Informatika', 'kp. kalapa Lima baros', '085893324274', 'islahatunnufusi07@gmail.com'),
(5, '1102171145', 'Elia Fajrin ', 'Matematika ', 'Kp. Sidagel', '08976543245', 'eliafajrin@gmail.com'),
(6, '098765435', 'Aprina Damayanti', 'Akutansi', 'Serang', '09876522678', 'aprina@gmail.com'),
(7, '1102657865', 'Ida Hamdiatun Nafsiah', 'Pendidikan sekolah dasar', 'Jakarta', '098765434512', 'idahamdiyatun@gmail.com'),
(9, '1102171142', 'Kherul Fatah', 'farmasi', 'Tanggerang', '08976543213', 'fatah@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `genre` varchar(10) NOT NULL,
  `born` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `username`, `email`, `password`, `genre`, `born`) VALUES
(1, 'nufusi', 'iisaja', 'iis@gmail.com', '123', 'perempuan', '0000-00-00'),
(2, 'iis', 'islahatunnufusi', 'islahatunnufusi@gmail.com', '$2y$10$8/ltFQpy2mB6F48QDArxeeJp9gmE6vM5N2CnM4uQ3j.THW.LRiNbC', 'Perempuan', '1998-07-11'),
(3, 'ida Hamdiyatu Nafsiah', 'idajelek', 'ida@gmail.com', '$2y$10$U60vCqk3rVDFhcqe3tnmoOT6hHP/Ila6uSqvort7jc8Liypy8F6Ia', 'Perempuan', '2008-11-30'),
(4, 'Elia Fajrin', 'eliafajrin', 'eliafajrin@gmail.com', '$2y$10$5PHInkb2hpHoz8TKb7ulO.iQlntGHS.d/GKKILzci51iuo1QrvfZ6', 'Perempuan', '2001-01-07'),
(5, 'aprina damayanti', 'aprina', 'rina@gmail.com', '$2y$10$Fm5dUXqtKk4Hx/c8VPITz.yzJwXvmYf9l7fdYBCGOs5QWnIpyP/h2', 'Laki-Laki', '1998-02-03'),
(6, 'nurulazizah', 'nurul', 'nurul@gmail.com', '$2y$10$zN.KNJX87MOF1VXD4UefyOn9naK6SjJ4nf1MT1S.9MGYhEPKlJ6ty', 'Laki-Laki', '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
