<?php 

require'functions.php';

if (isset($_POST["registrasi"] ) ) {
	if (registrasi($_POST)>0){
		header("Location:login.php");
	}else{
		echo mysqli_error($conn);
	}
}

 ?>



<!DOCTYPE html>
<html>
<head>
	<title>Registrasi</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet"href="css/bootstrap.css">
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
	<h1>Halaman Registrasi</h1>
	<form role="form" action="" method="post">
		<div class="form-group">
			<label for="nama">Nama:</label>
			<input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan nama lengkap" autocomplete="off" required="Nama harus di isi">
		</div>
		<div class="form-group">
			<label for="username">Username:</label>
			<input type="text" class="form-control" id="username" name="username" placeholder="Masukka Usename" autocomplete="off" required="Username wajib di isi">
		</div>
		<div class="form-group">
			<label for="email">E-mail address:</label>
			<input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Alamat E-mail Anda" autocomplete="off" required="Alamat E-mail awib di isi">
		</div>
		<div class="form-group">
			<label for="pwd">Password:</label>
			<input type="password" class="form-control" id="pwd" name="password" placeholder="Masukkan Kata sandi" required="Password Harus di Isi">
		</div>
		<div class="form-group">
			<label for="pwd2">Konfirmasi Password:</label>
			<input type="password" class="form-control" id="pwd2" name="password2" placeholder="Ulangi Katasandi Anda" required="Password Harus di Isi" >
		</div>

		<div class="form-group">
			<label for="sel1">Jenis Kelamin:</label>
				<select class="form-control" id="sel1" name="genre">
					<option>Laki-Laki</option>
					<option>Perempuan</option>
				</select>
		</div>
		<div class="form-group">
			<label for="born">Tanggal Lahir:</label>
			<input type="date" class="form-control" id="born" name="born">
		</div>
			<button type="submit" class="btn btn-default" name="registrasi">Daftar</button>
	</form>
	</div>
</body>
</html>