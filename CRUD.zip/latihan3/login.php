<?php 

session_start();

if (isset($_SESSION['login'])) {
	header("location:admin,php");
	exit;
}


require'functions.php';

if (isset($_POST['masuk'])) {
	 $username =$_POST['username'];
	 $password =$_POST['password'];

	  //apakah username dan password sama dengan saat registrasi
	  $result=mysqli_query($conn,"SELECT * FROM users WHERE username='$username'");

	if (mysqli_num_rows($result)===1) {
		$row=mysqli_fetch_assoc($result);

		if (password_verify($password, $row["password"])) {

			//atur session
			$_SESSION["login"] = true;

			header("location:admin.php");
			exit;
		} 
	}
	$error =true;
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Halaman LogIn</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet"href="css/bootstrap.css">
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
	<h1 align="center">Halaman LogIn</h1>
	<?php if (isset($error)): ?>
		<p style="color: red; font-style: italic;">Username / Password salah</p>
	<?php endif; ?>
	<form role="form" action="" method="post">
		<div class="form-group">
			<label for="username">Username:</label>
			<input type="text" class="form-control" id="username" name="username" placeholder="Masukka Usename" autocomplete="off">
		</div>
		<div class="form-group">
			<label for="pwd">Password:</label>
			<input type="password" class="form-control" id="pwd" name="password" placeholder="Masukkan Kata sandi">
		</div>
			<button type="submit" class="btn btn-default" name="masuk">Masuk</button>
	</form>
	<br>
	<a href="registrasi.php">Anda bemum memiliki Akun? Daftar Terlebih Dahulu</a>
	</div>
</body>
</html>