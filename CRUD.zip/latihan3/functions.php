<?php 
// koneksi ke database
$conn =mysqli_connect('localhost','root','','perpustakaan');

function query($query){
	global $conn;
	$result=mysqli_query($conn, $query);
	$rows=[];
		while ($row =mysqli_fetch_assoc($result)){
			$rows[]=$row;
			
		}
	return $rows;
}

function tambah($data)
{
	global $conn;
	//mengambil data dari setiap elemen dalam form
		$npm = htmlspecialchars($data['npm']);
		$nama =$data['nama'];
		$jurusan =$data['jurusan'];
		$alamat =$data['alamat'];
		$nohp =$data['nohp'];
		$email =$data['email'];

		$query="INSERT INTO mahasiswa VALUES ('','$npm','$nama','$jurusan','$alamat','$nohp','$email')" ; 

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);


}

function hapus($id){
	global $conn;

mysqli_query($conn,"DELETE FROM mahasiswa WHERE id=$id");
return mysqli_affected_rows($conn);

} 



function ubah($data){
	global $conn;
		$id =$data['id'];
		$npm = htmlspecialchars($data['npm']);
		$nama =htmlspecialchars($data['nama']) ;
		$jurusan=htmlspecialchars($data['jurusan']) ;
		$alamat =htmlspecialchars($data['alamat']) ;
		$nohp = htmlspecialchars($data['nohp']) ;
		$email = htmlspecialchars ($data['email']);

		$query="UPDATE mahasiswa set
				npm ='$npm',
				nama ='$nama',
				jurusan ='$jurusan',
				alamat ='$alamat',
				nohp ='$nohp', 
				email ='$email' WHERE id=$id"; 

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}


	function cari($keyword){

		$query="SELECT FROM mahasiswa WHERE 
		npm like '%$keyword%' or
		nama like '%$keyword%' or
		jurusan like '%$keyword%' or
		alamat like '%$keyword%' or
		nohp like '%$keyword%' or
		email like '%$keyword%'
		";

		return query($query);
	}

function registrasi($data){
	global $conn;

	$nama =$data['nama'];
	$username =strtolower(stripcslashes($data["username"]));
	$email =$data['email'];
	$password =mysqli_real_escape_string($conn, $data['password']);
	$password2 =mysqli_real_escape_string($conn, $data['password2']);
	$genre =$data['genre']; 
	$born =$data['born']; 

 		//cara apakah user sudah dipilih atau belum
		$result =mysqli_query($conn,"SELECT username FROM users WHERE username='$username'");
 
	if (mysqli_fetch_assoc($result)) {
		echo "<script>
					alert('Username yang dipilih sudah digunakan');
			  </script>
			  ";
			   return false;
	}
		

		//cek konfirmasi password sama dengan password
	if ($password !== $password2) {
		echo "<script>
					alert('Konfirmasi Password tidak sesuai');
			  </script>
			  ";
			  return false;
	}

		// enkripsi password
	$password= password_hash($password,PASSWORD_DEFAULT);

	mysqli_query($conn,"INSERT INTO users VALUES ('','$nama','$username','$email','$password','$genre','$born')");

	return mysqli_affected_rows($conn);
	header("Location:admin.php");
}


 ?>











