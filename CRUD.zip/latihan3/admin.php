<?php 
session_start();

if (!isset($_SESSION['login'])) {
	header("location:login.php");
	exit;
}

 //koneksi ke database

require 'functions.php';
// memanggil data di database 
$mahasiswa =query("SELECT * FROM mahasiswa");

	//untuk menampilkan urutan berdasarkan urutan
			// urutan ascending
				//$mahasiswa =query("SELECT * FROM mahasiswa WHERE id assc");
 			// urutan discending
				//$mahasiswa =query("SELECT * FROM mahasiswa WHERE id disc");
			
if (isset($_POST["cari"])){
	$mahasiswa = cari($_POST['keyword']);
}
//untuk menamplkan hasil dari query
	//var_dump($a);
// untuk mengampilkan hasil queri yang akan di panggil
	//$p =mysqli_fetch_assoc($result);
		//var_dump($p['nama'])
// $data = "SELECT * FROM pengunjung";
// $mahasiswa = query($data);
// echo $mahasiswa;
?>

<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
</head>
<body>
	<h1 align="CENTER">DATA MAHASISWA</h1>
	<a href="tambah.php">Tambah Data mahasiswa</a><br><br>

	<form action="" method="POST">
		<input type="text" name="keyword" size="40" autofocus placeholder="masukkan keyword pencarian..." autocomplete="off" >
		<button type="submit" name="cari">Cari</button>
	</form>
	<br>
<form>
	<table border="1" colpadding="20" cellspacing="0">
		<tr>
			<th>No.</th>
			<th>AKSI</th>
			<th>NPM</th>
			<th>NAMA</th>
			<th>JURUSAN</th>
			<th>ALAMAT</th>
			<th>NO HP</th>
			<th>E-MAIL</th>
		</tr>
		<?php $i=1;  ?>
			<?php foreach ($mahasiswa as $p): ?>
		<tr>
			<td><?=$i;  ?></td>
			<td>
				<a href="ubah.php?id=<?=$p["id"];?>">Ubah |</a>
				<a href="hapus.php?id=<?=$p["id"];?>"
				   onclic="return confirm('yakin data akan dihapus');">Hapus</a>
			</td>
			<td><?=$p['npm']  ?></td>
			<td><?=$p['nama']  ?></td>
			<td><?=$p['jurusan']  ?></td>
			<td><?=$p['alamat']  ?></td>
			<td><?=$p['nohp']  ?></td>
			<td><?=$p['email']  ?></td>
			<?php  $i ++; ?>
		
		</tr> 
		<?php endforeach; ?>
	</table>
	<a href="login.php">Logout</a>
</form>

</body>
</html>