<?php 

session_start();
if (!isset($_SESSION['login'])) {
	header("location:login.php");
	exit;
}
	//koneksi ke database.... dengan cara menghubungkan ke fun
require 'functions.php';

	//mengecek apakah tombol submit sudah di tekan atau belum
if (isset($_POST["submit"])) {
	if (Tambah($_POST)>0) {
		echo 
			"<script> alert ('Data telah ditambahkan');
					 document.location.href='admin.php';
			</script>
			";
	}
	else{
		echo
		"<script> alert ('Data gagal ditambahkan');
			     document.location.href='admin.php';
		</script>
		";
		}
}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Tambah Mahasiswa</title>
 </head>
 <body>
 	<h1>Penambahan data mahasiswa</h1>
 	<form action="" method="POST">
 		<ul>
 			<li>
 				<label for="npm">NPM :</label>
 				<input type="text" name="npm" id="npm" required>
 			</li>
 			<BR>
 			<li>
 				<label for="nama">NAMA :</label>
 				<input type="text" name="nama" id="nama" required>
 			</li>
 			<br>
 			<li>
 				<label for="jurusan">JURUSAN :</label >
 				<input type="text" name="jurusan" id="jurusan" required>
 			</li>
 			<br>
 			<li>
 				<label for="alamat">ALAMAT :</label>
 				<input type="text" name="alamat" id="alamat" required>
 			</li>
 			<br>
 			<li>
 				<label for="nohp">NO HP :</label>
 				<input type="text" name="nohp" id="nohp"required>
 			</li>
 			<br>
 			<li>
 				<label for="email">E-MAIL :</label>
 				<input type="text" name="email" id="email"required>
 			</li>
 		</ul>
 		<button type="submit" name="submit">Tambahkan</button>
 	</form>
 		
 </body>
 </html>