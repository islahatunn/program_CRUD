<?php 

session_start();
if (!isset($_SESSION['login'])) {
	header("location:login.php");
	exit;
}


	//koneksi ke database.... dengan cara menghubungkan ke fun
require 'functions.php';

//ambil data dari url
$id = $_GET["id"];

//query data mahasiswa berdasarkan id

$mhs =query("SELECT * FROM mahasiswa WHERE id=$id")[0];


	//mengecek apakah tombol submit sudah di tekan atau belum
if (isset($_POST["submit"])) {
	if (ubah($_POST)>0) {
		echo 
			"<script> alert ('Data telah diubah');
					 document.location.href='admin.php';
			</script>
			";
	}
	else{
		echo
		"<script> alert ('Data gagal diubah');
			     document.location.href='admin.php';
		</script>
		";
		}
}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Tambah Mahasiswa</title>
 </head>
 <body>
 	<h1>Penambahan data mahasiswa</h1>
 	<form action="" method="POST">
 		<input type="" name="id" value="<?= $mhs["id"];?>" hidden>
 		<ul>
 			<li>
 				<label for="npm">NPM :</label>
 				<input type="text" name="npm" id="npm" required value="<?= $mhs['npm'];?>">
 			</li>
 			<BR>
 			<li>
 				<label for="nama">NAMA :</label>
 				<input type="text" name="nama" id="nama" required value="<?= $mhs['nama'];?>">
 			</li>
 			<br>
 			<li>
 				<label for="jurusan">JURUSAN :</label >
 				<input type="text" name="jurusan" id="jurusan" required value="<?= $mhs['jurusan'];?>">
 			</li>
 			<br>
 			<li>
 				<label for="alamat">ALAMAT :</label>
 				<input type="text" name="alamat" id="alamat" required value="<?= $mhs['alamat'];?>">
 			</li>
 			<br>
 			<li>
 				<label for="nohp">NO HP :</label>
 				<input type="text" name="nohp" id="nohp"required value="<?= $mhs['nohp'];?>">
 			</li>
 			<br>
 			<li>
 				<label for="email">E-MAIL :</label>
 				<input type="text" name="email" id="email"required value="<?= $mhs['email'];?>">
 			</li>
 		</ul>
 		<button type="submit" name="submit">Tambahkan</button>
 	</form>
 		
 </body>
 </html>